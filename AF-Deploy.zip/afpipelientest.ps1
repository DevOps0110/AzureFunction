#Kudo API to deploy zip file into server
param([string]$user, [string]$pass, [string]$site, [string]$filePath)
#$user = "asfa-nsrpipeline"
#$pass = "Dinner@3"
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $user, $pass)))
$apiUrl = "https://$site.scm.azurewebsites.net/api/zip/site/wwwroot"
#$filePath = "D:\ZipDeploy\AF.zip"
Invoke-RestMethod -Uri $apiUrl -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Method PUT -InFile $filePath -ContentType "multipart/form-data" | Out-Null
